#pragma once
#include "Components.h"

class ItemComponent : public Component
{
public:
	int type; //0 = medkit, 1 = ammobag

};